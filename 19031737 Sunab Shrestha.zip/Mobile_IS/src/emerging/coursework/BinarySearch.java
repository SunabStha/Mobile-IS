/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emerging.coursework;

public class BinarySearch {

    public static int binarySearch(int a[], int low, int high, int find) {
        if (low <= high) {
            int mid = low + (high - low) / 2;
            if ((mid == 0 || find > a[mid - 1]) && a[mid] == find) {
                return mid;
            } else if (find > a[mid]) {
                return binarySearch(a, (mid + 1), high, find);
            } else {
                return binarySearch(a, low, (mid - 1), find);
            }
        }
        return -1;
    }
}
