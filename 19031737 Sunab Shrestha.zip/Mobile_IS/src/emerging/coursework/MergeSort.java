package emerging.coursework;

public class MergeSort {

    public static void sort(int[] array) {
        if (array.length <= 1) {
            return;
        }
        int[] leftSide = new int[array.length / 2];
        int[] rightSide = new int[array.length - leftSide.length];
        // Copy the leftSide half of a into leftSide, the rightSide half into rightSide
        for (int i = 0; i < leftSide.length; i++) {
            leftSide[i] = array[i];
        }
        for (int i = 0; i < rightSide.length; i++) {
            rightSide[i] = array[leftSide.length + i];
        }
        sort(leftSide);
        sort(rightSide);
        merge(leftSide, rightSide, array);
    }

    private static void merge(int[] leftSide, int[] rightSide, int[] array) {
        int left = 0; 
        int right = 0; 
        int index = 0; 

       
        while (left < leftSide.length && right < rightSide.length) {
            if (leftSide[left] < rightSide[right]) {
                array[index] = leftSide[left];
                left++;
            } else {
                array[index] = rightSide[right];
                right++;
            }
            index++;
        }

       
        while (left < leftSide.length) {
            array[index] = leftSide[left];
            left++;
            index++;
        }
        // Copy any remaining entries of the rightSide half
        while (right < rightSide.length) {
            array[index] = rightSide[right];
            right++;
            index++;
        }
    }
}
